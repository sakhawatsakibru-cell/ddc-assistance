"""DDC Assistant Utilities and UI Components Package"""
